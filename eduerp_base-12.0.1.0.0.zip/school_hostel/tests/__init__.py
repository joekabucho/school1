# See LICENSE file for full copyright and licensing details.

# ----------------------------------------------------------
# A Module to Hostel Management System
# ----------------------------------------------------------

from . import test_hostel
